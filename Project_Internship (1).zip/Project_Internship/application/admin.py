from django.contrib import admin

from application.models import *

# Register your models here.

admin.site.register(driver_table)


